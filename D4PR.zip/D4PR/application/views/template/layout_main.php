<?php $this->load->view('template/header.inc'); 

              $this->load->view('template/sidebar.inc'); 

        
              $this->load->view($subview); 


    
         $this->load->view('template/footer.inc');
         
         







